public interface Daftar {
  int hitungRata();
  void check();
}